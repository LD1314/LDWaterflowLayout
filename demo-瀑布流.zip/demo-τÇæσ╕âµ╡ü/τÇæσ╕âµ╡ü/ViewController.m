//
//  ViewController.m
//  瀑布流
//
//  Created by iOS Tedu on 16/8/11.
//  Copyright © 2016年 huaxu. All rights reserved.
//

#import "ViewController.h"
#import "LDWaterflowLayout.h"
#import "LDShop.h"
#import "MJExtension.h"
#import "MJRefresh.h"
#import "LDShopCell.h"

@interface ViewController () <UICollectionViewDataSource, LDWaterflowLayoutDelegate>
/** 所有的商品数据 */
@property (nonatomic, strong) NSMutableArray *shops;

@property (nonatomic, weak) UICollectionView *collectionView;

@end

@implementation ViewController

- (NSMutableArray *)shops {
    if (!_shops) {
        _shops = [NSMutableArray array];
    }
    return _shops;
}

static NSString *const LDShopId = @"shop";

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self setupLayout];
    
    [self setupRefresh];
}

- (void)setupRefresh {
    self.collectionView.header = [MJRefreshHeader headerWithRefreshingTarget:self refreshingAction:@selector(loadNewShops)];
    //一进入就开始刷新
    [self.collectionView.header beginRefreshing];
    
    self.collectionView.footer = [MJRefreshAutoNormalFooter footerWithRefreshingTarget:self refreshingAction:@selector(loadMoreShops)];
    self.collectionView.footer.hidden = YES;
}

- (void)loadNewShops {
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        NSArray *shops = [LDShop objectArrayWithFilename:@"1.plist"];
        [self.shops removeAllObjects];
        [self.shops addObjectsFromArray:shops];
        
        //刷新数据
        [self.collectionView reloadData];
        //结束刷新
        [self.collectionView.header endRefreshing];
    });
}

- (void)loadMoreShops {
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        NSArray *shops = [LDShop objectArrayWithFilename:@"1.plist"];
        [self.shops addObjectsFromArray:shops];
        
        //刷新数据
        [self.collectionView reloadData];
        //结束刷新
        [self.collectionView.footer endRefreshing];
    });
}

- (void)setupLayout {
    //创建布局
    LDWaterflowLayout *layout = [[LDWaterflowLayout alloc] init];
    layout.delegate = self;
    
    //创建collectionView
    UICollectionView *collectionView = [[UICollectionView alloc] initWithFrame:self.view.bounds collectionViewLayout:layout];
    collectionView.dataSource = self;
    collectionView.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:collectionView];
    
    //注册
    [collectionView registerNib:[UINib nibWithNibName:NSStringFromClass([LDShopCell class]) bundle:nil] forCellWithReuseIdentifier:LDShopId];
    
    self.collectionView = collectionView;
}

#pragma mark - UICollectionViewDataSource
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    self.collectionView.footer.hidden = self.shops.count == 0;
    return self.shops.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    LDShopCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:LDShopId forIndexPath:indexPath];
    
    cell.shop = self.shops[indexPath.item];
    
    return cell;
}

#pragma mark - LDWaterflowLayoutDelegate
- (CGFloat)waterflowLayout:(LDWaterflowLayout *)waterflowLayout heightForItemAtIndex:(NSUInteger)index itemWidth:(CGFloat)itemWidth {
    LDShop *shop = self.shops[index];
    
    return itemWidth * shop.h / shop.w;
}

//- (CGFloat)columnCountInWaterflowLayout:(LDWaterflowLayout *)waterflowLayout {
//    return 3;
//}

//- (CGFloat)rowMarginInWaterflowLayout:(LDWaterflowLayout *)waterflowLayout {
//    return 20;
//}
//
//- (CGFloat)columnMarginInWaterflowLayout:(LDWaterflowLayout *)waterflowLayout {
//    return 15;
//}
//
//- (UIEdgeInsets)edgeInsetsInWaterflowLayout:(LDWaterflowLayout *)waterflowLayout {
//    return UIEdgeInsetsMake(10, 20, 30, 40);
//}

@end
