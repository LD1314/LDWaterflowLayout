//
//  AppDelegate.h
//  瀑布流
//
//  Created by iOS Tedu on 16/8/11.
//  Copyright © 2016年 huaxu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

