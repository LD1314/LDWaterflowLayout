//
//  LDShopCell.h
//  瀑布流
//
//  Created by iOS Tedu on 16/8/11.
//  Copyright © 2016年 huaxu. All rights reserved.
//

#import <UIKit/UIKit.h>
@class LDShop;
@interface LDShopCell : UICollectionViewCell
@property (nonatomic, strong) LDShop *shop;
@end
