//
//  XMGShop.m
//  06-瀑布流
//
//  Created by apple on 14-7-28.
//  Copyright (c) 2014年 小码哥. All rights reserved.
//

#import "XMGShop.h"

@implementation XMGShop

@end
